CREATE OR REPLACE PACKAGE JO_BCJOCAB
IS
    /*****************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad         : JO_BCJOCAB
    Descripcion    : Componente de negocio de la aplicaci�n JOCAB.
    Autor          : Juan Manuel ospina
    Fecha          : 20-03-2015

    Historia de Modificaciones
    Fecha             Autor             Modificacion
    =========         =========         ====================
    20-03-2015        jospina            Creaci�n.
    ******************************************************************/
    --------------------------------------------
    -- Constantes GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Variables GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Funciones y Procedimientos PUBLICAS DEL PAQUETE
    --------------------------------------------

    /***************************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad:         CopyAirplanesIntoAudit
    Descripci�n:    Trae las aerolineas a partir del ID
    ***************************************************************************/
    type vuelo_aerolineas IS table of jo_flight%rowtype index BY binary_integer;
    PROCEDURE CopyAirplanesIntoAudit (
        inuLasValue         number,
        vuelo_aerolinea out vuelo_aerolineas
    );
END JO_BCJOCAB;
/
CREATE OR REPLACE PACKAGE BODY JO_BCJOCAB
IS
    /*****************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad         : JO_BCJOCAB
    Descripcion    : Componente de negocio de la aplicaci�n JOCAB.
    Autor          : Juan Manuel ospina
    Fecha          : 20-03-2015

    Historia de Modificaciones
    Fecha             Autor             Modificacion
    =========         =========         ====================
    20-03-2015        jospina            Creaci�n.
    ******************************************************************/
    --------------------------------------------
    -- Constantes GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Variables GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Funciones y Procedimientos PUBLICAS DEL PAQUETE
    --------------------------------------------

    /***************************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad:         CopyAirplanesIntoAudit
    Descripci�n:    Trae las aerolineas a partir del ID
    ***************************************************************************/
   PROCEDURE CopyAirplanesIntoAudit
    (
        inuLasValue         number,
        vuelo_aerolinea out vuelo_aerolineas
    )
    IS  fallo_registro varchar2(200);
        query_insert varchar2(200);
        ocuDataCursor constants.tyRefCursor;
        sbQuery varchar2(2000);
    ------------------------------------------------------------------------
    ------Consulta/cursor que me trae los vuelos del ultimo mes-------------
    ------------------------------------------------------------------------
        CURSOR cu_infoVuelos
        (
            inuLastValue        number
        )
            IS
            SELECT /*+ index(jo_airplane pk_jo_airplane)*/
                *
           FROM jo_flight
           WHERE LANDING_TIME BETWEEN ADD_MONTHS(CURRENT_TIMESTAMP,-1) AND CURRENT_TIMESTAMP
            AND jo_flight.jo_flight_id>inuLastValue;
    BEGIN
      open cu_infoVuelos(inuLasValue);
     fetch cu_infoVuelos BULK collect INTO vuelo_aerolinea limit 100;
     close cu_infoVuelos;

    ------------------------------------------------------------------------
    -----------------Inserto los datos en la tabla--------------------------
    ------------------------------------------------------------------------
    for i in vuelo_aerolinea.first..vuelo_aerolinea.last

    loop
        if vuelo_aerolinea.exists(i) then
            query_insert:='INSERT INTO jo_last_month_flights values('''||vuelo_aerolinea(i).jo_flight_id
            ||''','''||TO_TIMESTAMP(vuelo_aerolinea(i).landing_time)||''','''
            ||vuelo_aerolinea(i).status||''')';
           EXECUTE IMMEDIATE query_insert;
        else
            dbms_output.put_line('Codigo->'||i||':no existe');
            END if;
    end loop;
     EXCEPTION
            when ex.CONTROLLED_ERROR then
                raise ex.CONTROLLED_ERROR;
            when others then fallo_registro:='si';

     END CopyAirplanesIntoAudit;
END JO_BCJOCAB;
/