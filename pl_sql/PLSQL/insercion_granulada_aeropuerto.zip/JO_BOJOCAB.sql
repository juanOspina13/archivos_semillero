CREATE OR REPLACE PACKAGE JO_BOJOCAB
IS
 /*****************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad         : JO_BOJOCAB
    Descripcion    : Componente de negocio de la aplicaci�n JOCAB.
    Autor          : Juan Manuel ospina
    Fecha          : 20-03-2015

    Historia de Modificaciones
    Fecha             Autor             Modificacion
    =========         =========         ====================
    20-03-2015        jospina            Creaci�n.
    ******************************************************************/
    --------------------------------------------
    -- Constantes GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Variables GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Funciones y Procedimientos PUBLICAS DEL PAQUETE
    --------------------------------------------

    /***************************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad:         processData
    Descripci�n:    Realiza las inserciones de los vuelos del ultimo mes
    de manera granulada
    ***************************************************************************/
    PROCEDURE processData;
END JO_BOJOCAB;
/
CREATE OR REPLACE PACKAGE BODY JO_BOJOCAB
IS
 /*****************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad         : JO_BOJOCAB
    Descripcion    : Componente de negocio de la aplicaci�n JOCAB.
    Autor          : Juan Manuel ospina
    Fecha          : 20-03-2015

    Historia de Modificaciones
    Fecha             Autor             Modificacion
    =========         =========         ====================
    20-03-2015        jospina            Creaci�n.
    ******************************************************************/
    --------------------------------------------
    -- Constantes GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Variables GLOBALES Y PUBLICAS DEL PAQUETE
    --------------------------------------------
    --------------------------------------------
    -- Funciones y Procedimientos PUBLICAS DEL PAQUETE
    --------------------------------------------

    /***************************************************************************
    Propiedad intelectual de Open International Systems (c).

    Unidad:         processData
    Descripci�n:    Realiza las inserciones de los vuelos del ultimo mes
    de manera granulada
    ***************************************************************************/
    PROCEDURE processData
    IS
        nuLastValue         number := 1;
        nuIndex             number;
        vuelo_aerolinea     JO_BCJOCAB.vuelo_aerolineas;
    BEGIN
        loop
            JO_BCJOCAB.CopyAirplanesIntoAudit(nuLastValue, vuelo_aerolinea);
            nuIndex :=  vuelo_aerolinea.first;
            exit when nuIndex IS null;
            loop
                exit when nuIndex IS null;
                nuIndex := vuelo_aerolinea.next(nuIndex);
            END loop;
            nuLastValue :=  vuelo_aerolinea(vuelo_aerolinea.last).jo_flight_id;
        END loop;

    END processData;
END JO_BOJOCAB;
/