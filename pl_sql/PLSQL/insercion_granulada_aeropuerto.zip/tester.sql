DECLARE
    nuError     NUMBER;
    sbError     VARCHAR2(2000);
    type vuelo_aerolineas IS table of jo_flight%rowtype index BY binary_integer;
    vuelos vuelo_aerolineas;
BEGIN
    dbms_output.put_Line('INICIO=['||TO_CHAR(sysdate, 'DD-MM-YYYY HH24:MI:SS')||']');
    JO_BOJOCAB.processData;
    dbms_output.put_Line('FIN=['||TO_CHAR(sysdate, 'DD-MM-YYYY HH24:MI:SS')||']');
END;