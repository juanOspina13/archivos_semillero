--
-- Propiedad intelectual de OPEN International Systems Ltda
--
-- Archivo       : crJO_cliente.sql
-- Autor         : Juan Ospina
-- Fecha         : <28-02-2015>
--
-- Descripci�n   : Creaci�n de tabla jo_cliente de la empresa Ficticia S.A
-- Observaciones :
--
--

CREATE TABLE JO_CLIENTE
(
    cliecodi        NUMBER(5),
    clienomb        VARCHAR2(200)
);