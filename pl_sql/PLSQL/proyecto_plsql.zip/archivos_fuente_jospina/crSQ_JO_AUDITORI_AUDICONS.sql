--
-- Propiedad intelectual de OPEN International Systems Ltda
--
-- Archivo       : crSQ_JO_AUDITORI_AUDICONS.sql
-- Autor         : Juan Ospina
-- Fecha         : <27-02-2015>
--
-- Descripci�n   : Creaci�n secuencia crSQ_JO_AUDITORI_AUDICONS de la empresa Ficticia S.A
-- Observaciones :
--
--

CREATE SEQUENCE SQ_JO_AUDITORI_AUDICONS
    increment BY 1 start
    with 1
    maxvalue 9999999
    Nocycle