--
-- Propiedad intelectual de OPEN International Systems Ltda
--
-- Archivo       : crSQ_JO_INCOLOG_INLOCONS.sql
-- Autor         : Juan Ospina
-- Fecha         : <27-02-2015>
--
-- Descripci�n   : Creaci�n secuencia SQ_JO_INCOLOG_INLOCONS de la empresa Ficticia S.A
-- Observaciones :
--
--

CREATE SEQUENCE SQ_JO_INCOLOG_INLOCONS
    increment BY 1 start
    with 1
    maxvalue 9999999
    Nocycle