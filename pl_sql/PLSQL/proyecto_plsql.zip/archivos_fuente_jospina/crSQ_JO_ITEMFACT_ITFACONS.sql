--
-- Propiedad intelectual de OPEN International Systems Ltda
--
-- Archivo       : crSQ_JO_ITEMFACT_ITFACONS.sql
-- Autor         : Juan Ospina
-- Fecha         : <27-02-2015>
--
-- Descripci�n   : Creaci�n secuencia SQ_JO_ITEMFACT_ITFACONS de la empresa Ficticia S.A
-- Observaciones :
--
--

 CREATE SEQUENCE SQ_JO_ITEMFACT_ITFACONS
    increment BY 1 start
    with 1
    maxvalue 9999999
    Nocycle