--
-- Propiedad intelectual de OPEN International Systems Ltda
--
-- Archivo       : crSQ_JO_PRODUCTO_PRODCONS.sql
-- Autor         : Juan Ospina
-- Fecha         : <27-02-2015>
--
-- Descripci�n   : Creaci�n secuencia SQ_JO_PRODUCTO_PRODCONS de la empresa Ficticia S.A
-- Observaciones :
--
--

CREATE SEQUENCE SQ_JO_PRODUCTO_PRODCONS
    increment BY 1 start
    with 1
    maxvalue 9999999
    Nocycle